this is the images folder
i just added this text because github wont allow me to add empty folder 